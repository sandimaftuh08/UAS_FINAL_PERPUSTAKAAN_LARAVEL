<?php $__env->startSection('title', 'Daftar Buku'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>
        <i class="bi bi-book"></i>
        Daftar Buku
    </h1>
    <a href="<?php echo e(route('buku.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle"></i> Tambah Buku
    </a>
    <a href="<?php echo e(route('buku.export')); ?>" class="btn btn-success">
        <i class="bi bi-file-excel"></i> Export Excel
    </a>
</div>


<div class="row mb-4">
    <div class="col-md-4">
        <div class="card border-primary">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">Total Buku</h6>
                        <h2 class="mb-0"><?php echo e($totalBuku); ?></h2>
                    </div>
                    <div class="text-primary">
                        <i class="bi bi-book-fill" style="font-size: 3rem;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card border-success">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">Buku Tersedia</h6>
                        <h2 class="mb-0"><?php echo e($bukuTersedia); ?></h2>
                    </div>
                    <div class="text-success">
                        <i class="bi bi-check-circle-fill" style="font-size: 3rem;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card border-danger">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">Buku Habis</h6>
                        <h2 class="mb-0"><?php echo e($bukuHabis); ?></h2>
                    </div>
                    <div class="text-danger">
                        <i class="bi bi-x-circle-fill" style="font-size: 3rem;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="card mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('buku.search')); ?>">
            <div class="row g-2 align-items-end">
                <div class="col-md-3">
                    <label class="form-label small">Keyword</label>
                    <input type="search" name="keyword" value="<?php echo e($keyword ?? ''); ?>" class="form-control" placeholder="Cari judul, pengarang, penerbit">
                </div>

                <div class="col-md-2">
                    <label class="form-label small">Kategori</label>
                    <select name="kategori" class="form-select">
                        <option value="">Semua</option>
                        <?php $__currentLoopData = ($kategoriOptions ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($opt); ?>" <?php echo e((isset($kategori) && $kategori == $opt) ? 'selected' : ''); ?>><?php echo e($opt); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-1">
                    <label class="form-label small">Tahun</label>
                    <select name="tahun" class="form-select">
                        <option value="">Semua</option>
                        <?php if(isset($tahunList)): ?>
                            <?php $__currentLoopData = $tahunList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $th): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($th); ?>" <?php echo e((isset($tahun) && $tahun == $th) ? 'selected' : ''); ?>><?php echo e($th); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="col-md-2">
                    <label class="form-label small">Ketersediaan</label>
                    <select name="ketersediaan" class="form-select">
                        <option value="">Semua</option>
                        <option value="tersedia" <?php echo e((isset($ketersediaan) && $ketersediaan == 'tersedia') ? 'selected' : ''); ?>>Tersedia</option>
                        <option value="habis" <?php echo e((isset($ketersediaan) && $ketersediaan == 'habis') ? 'selected' : ''); ?>>Habis</option>
                    </select>
                </div>

                <div class="col-md-1">
                    <label class="form-label small">Harga Min</label>
                    <input type="number" name="harga_min" class="form-control" min="0" value="<?php echo e($hargaMin ?? ''); ?>">
                </div>

                <div class="col-md-1">
                    <label class="form-label small">Harga Max</label>
                    <input type="number" name="harga_max" class="form-control" min="0" value="<?php echo e($hargaMax ?? ''); ?>">
                </div>

                <div class="col-md-2 text-end">
                    <button type="submit" class="btn btn-primary">Cari</button>
                    <a href="<?php echo e(route('buku.index')); ?>" class="btn btn-outline-secondary">Reset</a>
                </div>
            </div>
        </form>
    </div>
</div>

<?php if($bukus->count() > 0): ?>

<form id="bulk-delete-form" action="<?php echo e(route('buku.bulk-delete')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="card mb-4 border-warning">
        <div class="card-body">
            <div class="d-flex align-items-center justify-content-between gap-3">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="select-all" style="width: 1.25em; height: 1.25em; cursor: pointer;">
                    <label class="form-check-label" for="select-all" style="cursor: pointer;">
                        <strong>Pilih Semua</strong>
                    </label>
                </div>

                <div>
                    <span id="selected-count" class="badge bg-info">0 terpilih</span>
                    <button type="submit" id="bulk-delete-btn" class="btn btn-danger btn-sm ms-2" disabled>
                        <i class="bi bi-trash"></i> Hapus Terpilih
                    </button>
                </div>
            </div>
        </div>
    </div>
</form>


<?php $__empty_1 = true; $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php if (isset($component)) { $__componentOriginal4ac845093cfe0dfa116a4a1a20b2d959 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ac845093cfe0dfa116a4a1a20b2d959 = $attributes; } ?>
<?php $component = App\View\Components\BukuCard::resolve(['buku' => $buku] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buku-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\BukuCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ac845093cfe0dfa116a4a1a20b2d959)): ?>
<?php $attributes = $__attributesOriginal4ac845093cfe0dfa116a4a1a20b2d959; ?>
<?php unset($__attributesOriginal4ac845093cfe0dfa116a4a1a20b2d959); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ac845093cfe0dfa116a4a1a20b2d959)): ?>
<?php $component = $__componentOriginal4ac845093cfe0dfa116a4a1a20b2d959; ?>
<?php unset($__componentOriginal4ac845093cfe0dfa116a4a1a20b2d959); ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="alert alert-info">
        <i class="bi bi-info-circle"></i>
        Tidak ada data buku
        <?php if(isset($kategori)): ?>
            dengan kategori <strong><?php echo e($kategori); ?></strong>
        <?php endif; ?>
    </div>
<?php endif; ?>

<div class="text-center mt-4">
    <p class="text-muted">
        Menampilkan <?php echo e($bukus->count()); ?> buku
        <?php if(isset($kategori)): ?>
            dari kategori <strong><?php echo e($kategori); ?></strong>
        <?php endif; ?>
    </p>
</div>
<?php else: ?>


<?php $__empty_1 = true; $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php if (isset($component)) { $__componentOriginal4ac845093cfe0dfa116a4a1a20b2d959 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ac845093cfe0dfa116a4a1a20b2d959 = $attributes; } ?>
<?php $component = App\View\Components\BukuCard::resolve(['buku' => $buku] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('buku-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\BukuCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ac845093cfe0dfa116a4a1a20b2d959)): ?>
<?php $attributes = $__attributesOriginal4ac845093cfe0dfa116a4a1a20b2d959; ?>
<?php unset($__attributesOriginal4ac845093cfe0dfa116a4a1a20b2d959); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ac845093cfe0dfa116a4a1a20b2d959)): ?>
<?php $component = $__componentOriginal4ac845093cfe0dfa116a4a1a20b2d959; ?>
<?php unset($__componentOriginal4ac845093cfe0dfa116a4a1a20b2d959); ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="alert alert-info">
        <i class="bi bi-info-circle"></i>
        Tidak ada data buku
        <?php if(isset($kategori)): ?>
            dengan kategori <strong><?php echo e($kategori); ?></strong>
        <?php endif; ?>
    </div>
<?php endif; ?>

<div class="text-center mt-4">
    <p class="text-muted">
        Menampilkan <?php echo e($bukus->count()); ?> buku
        <?php if(isset($kategori)): ?>
            dari kategori <strong><?php echo e($kategori); ?></strong>
        <?php endif; ?>
    </p>
</div>

<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
<script>
    const selectAllCheckbox = document.getElementById('select-all');
    const bookCheckboxes = document.querySelectorAll('input[name="buku_ids[]"]');
    const bulkDeleteBtn = document.getElementById('bulk-delete-btn');
    const selectedCount = document.getElementById('selected-count');

    if (selectAllCheckbox && bookCheckboxes.length > 0) {
        selectAllCheckbox.addEventListener('change', function() {
            bookCheckboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
            updateBulkDeleteButton();
        });

        bookCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                updateBulkDeleteButton();

                const allChecked = Array.from(bookCheckboxes).every(cb => cb.checked);
                const someChecked = Array.from(bookCheckboxes).some(cb => cb.checked);

                selectAllCheckbox.checked = allChecked;
                selectAllCheckbox.indeterminate = someChecked && !allChecked;
            });
        });
    }

    function updateBulkDeleteButton() {
        const checkedCount = document.querySelectorAll('input[name="buku_ids[]"]:checked').length;

        if (selectedCount) {
            selectedCount.textContent = checkedCount + ' terpilih';
        }

        if (bulkDeleteBtn) {
            bulkDeleteBtn.disabled = checkedCount === 0;
        }
    }

    const bulkDeleteForm = document.getElementById('bulk-delete-form');
    if (bulkDeleteForm) {
        bulkDeleteForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const checkedCount = document.querySelectorAll('input[name="buku_ids[]"]:checked').length;

            if (checkedCount === 0) {
                alert('Pilih minimal satu buku untuk dihapus.');
                return false;
            }

            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    title: 'Konfirmasi Hapus',
                    text: `Apakah Anda yakin ingin menghapus ${checkedCount} buku terpilih?`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Ya, Hapus!',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        bulkDeleteForm.submit();
                    }
                });
            } else {
                if (!confirm(`Apakah Anda yakin ingin menghapus ${checkedCount} buku terpilih?`)) {
                    return false;
                } else {
                    bulkDeleteForm.submit();
                }
            }
        });
    }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\PROJECT-LARAVEL\resources\views/buku/index.blade.php ENDPATH**/ ?>