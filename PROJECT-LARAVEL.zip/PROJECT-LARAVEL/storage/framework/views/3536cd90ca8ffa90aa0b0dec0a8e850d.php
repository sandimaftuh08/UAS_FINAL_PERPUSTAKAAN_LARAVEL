<?php $__env->startSection('title', 'Laporan Transaksi'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1><i class="bi bi-file-text"></i> Laporan Transaksi</h1>
    <a href="<?php echo e(route('transaksi.laporan.pdf', request()->query())); ?>" class="btn btn-danger">
        <i class="bi bi-file-pdf"></i> Export PDF
    </a>
</div>

<div class="card mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('transaksi.laporan')); ?>" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label small">Dari Tanggal</label>
                <input type="date" name="dari_tanggal" class="form-control" value="<?php echo e(request('dari_tanggal')); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label small">Sampai Tanggal</label>
                <input type="date" name="sampai_tanggal" class="form-control" value="<?php echo e(request('sampai_tanggal')); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label small">Status</label>
                <select name="status" class="form-select">
                    <option value="Semua">Semua</option>
                    <option value="Dipinjam" <?php echo e(request('status') == 'Dipinjam' ? 'selected' : ''); ?>>Dipinjam</option>
                    <option value="Dikembalikan" <?php echo e(request('status') == 'Dikembalikan' ? 'selected' : ''); ?>>Dikembalikan</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small">Anggota</label>
                <select name="anggota_id" class="form-select">
                    <option value="">Semua</option>
                    <?php $__currentLoopData = $anggotaList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($a->id); ?>" <?php echo e(request('anggota_id') == $a->id ? 'selected' : ''); ?>><?php echo e($a->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2 d-grid">
                <button type="submit" class="btn btn-primary">Filter</button>
            </div>
        </form>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-6">
        <div class="card border-primary">
            <div class="card-body">
                <h6 class="text-muted">Total Transaksi</h6>
                <h2><?php echo e($totalTransaksi); ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card border-danger">
            <div class="card-body">
                <h6 class="text-muted">Total Denda</h6>
                <h2>Rp <?php echo e(number_format($totalDenda, 0, ',', '.')); ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Kode</th><th>Buku</th><th>Anggota</th><th>Tgl Pinjam</th><th>Tgl Kembali</th><th>Status</th><th>Denda</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><code><?php echo e($t->kode_transaksi); ?></code></td>
                            <td><?php echo e($t->buku->judul); ?></td>
                            <td><?php echo e($t->anggota->nama); ?></td>
                            <td><?php echo e($t->tanggal_pinjam->format('d M Y')); ?></td>
                            <td><?php echo e($t->tanggal_kembali_aktual ? $t->tanggal_kembali_aktual->format('d M Y') : '-'); ?></td>
                            <td><span class="badge bg-<?php echo e($t->status === 'Dikembalikan' ? 'success' : 'primary'); ?>"><?php echo e($t->status); ?></span></td>
                            <td>Rp <?php echo e(number_format($t->denda, 0, ',', '.')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="7" class="text-center text-muted">Tidak ada data transaksi</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\PROJECT-LARAVEL\resources\views/transaksi/laporan.blade.php ENDPATH**/ ?>