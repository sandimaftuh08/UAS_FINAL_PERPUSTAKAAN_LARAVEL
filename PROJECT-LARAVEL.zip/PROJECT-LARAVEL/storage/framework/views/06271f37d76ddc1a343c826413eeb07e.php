<?php $__env->startSection('title', 'Daftar Transaksi'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1><i class="bi bi-arrow-left-right"></i> Daftar Transaksi</h1>
    <div>
        <a href="<?php echo e(route('transaksi.laporan')); ?>" class="btn btn-outline-primary me-2">
            <i class="bi bi-file-text"></i> Laporan
        </a>
        <a href="<?php echo e(route('transaksi.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> Pinjam Buku
        </a>
    </div>
</div>

<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-2">
            <div class="col-md-3">
                <select name="status" class="form-select" onchange="this.form.submit()">
                    <option value="">Semua Status</option>
                    <option value="Dipinjam" <?php echo e(request('status') == 'Dipinjam' ? 'selected' : ''); ?>>Dipinjam</option>
                    <option value="Dikembalikan" <?php echo e(request('status') == 'Dikembalikan' ? 'selected' : ''); ?>>Dikembalikan</option>
                </select>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Kode</th>
                        <th>Buku</th>
                        <th>Anggota</th>
                        <th>Tgl Pinjam</th>
                        <th>Tgl Kembali</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><code><?php echo e($t->kode_transaksi); ?></code></td>
                            <td><?php echo e($t->buku->judul); ?></td>
                            <td><?php echo e($t->anggota->nama); ?></td>
                            <td><?php echo e($t->tanggal_pinjam->format('d M Y')); ?></td>
                            <td><?php echo e($t->tanggal_kembali_rencana->format('d M Y')); ?></td>
                            <td>
                                <?php if($t->status === 'Dikembalikan'): ?>
                                    <span class="badge bg-success">Dikembalikan</span>
                                <?php elseif($t->is_terlambat): ?>
                                    <span class="badge bg-danger">Terlambat <?php echo e($t->hari_terlambat); ?> hari</span>
                                <?php else: ?>
                                    <span class="badge bg-primary">Dipinjam</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('transaksi.show', $t->id)); ?>" class="btn btn-sm btn-info text-white">
                                    <i class="bi bi-eye"></i> Detail
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="7" class="text-center text-muted">Belum ada data transaksi</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\PROJECT-LARAVEL\resources\views/transaksi/index.blade.php ENDPATH**/ ?>