<footer class="footer-custom border-top">
    <div class="container">
        <div class="row py-4">
            <div class="col-md-6">
                <h5>
                    <i class="bi bi-book-fill text-primary"></i> Sistem Perpustakaan
                </h5>
                <p class="footer-text mb-0">
                    Sistem Manajemen Perpustakaan menggunakan Laravel 13
                </p>
            </div>

            <div class="col-md-3">
                <h6>Menu</h6>
                <ul class="list-unstyled">
                    <li><a href="{{ url('/') }}" class="footer-link text-decoration-none">Home</a></li>
                    <li><a href="{{ route('buku.index') }}" class="footer-link text-decoration-none">Buku</a></li>
                    <li><a href="{{ route('anggota.index') }}" class="footer-link text-decoration-none">Anggota</a></li>
                </ul>
            </div>

            <div class="col-md-3">
                <h6>Kontak</h6>
                <p class="footer-text small mb-0">
                    <i class="bi bi-envelope"></i> perpustakaan@example.com<br>
                    <i class="bi bi-telephone"></i> (021) 1234-5678
                </p>
            </div>
        </div>

        <div class="row border-top pt-3">
            <div class="col text-center">
                <p class="footer-text small mb-0">
                    &copy; {{ date('Y') }} Sistem Perpustakaan.
                    Built with <i class="bi bi-heart-fill text-danger"></i> using Laravel 13.
                </p>
            </div>
        </div>
    </div>
</footer>


